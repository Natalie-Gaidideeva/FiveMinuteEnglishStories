package com.example.shortshortstories;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Tab4Genres extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_4_genres);
    }
}
