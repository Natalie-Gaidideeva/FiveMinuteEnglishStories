package com.example.shortshortstories;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Tab2Latest extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_2_latest);
    }
}
