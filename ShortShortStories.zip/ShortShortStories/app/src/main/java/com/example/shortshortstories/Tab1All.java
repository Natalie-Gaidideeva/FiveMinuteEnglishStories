package com.example.shortshortstories;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Tab1All extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tab_1_all);
    }
}
